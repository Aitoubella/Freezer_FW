/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _DRV_GFX_ILI9341_CMD_DEFS_H    /* Guard against multiple inclusion */
#define _DRV_GFX_ILI9341_CMD_DEFS_H


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */


/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


    /* ************************************************************************** */
    /* ************************************************************************** */
    /* Section: Constants                                                         */
    /* ************************************************************************** */
    /* ************************************************************************** */

    /*  A brief description of a section can be given directly below the section
        banner.
     */


    /* ************************************************************************** */
    /** Descriptive Constant Name

      @Summary
        Brief one-line summary of the constant.
    
      @Description
        Full description, explaining the purpose and usage of the constant.
        <p>
        Additional description in consecutive paragraphs separated by HTML 
        paragraph breaks, as necessary.
        <p>
        Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
      @Remarks
        Any additional remarks
     */
/* ************************************************************************** */
/** ILI9488_CMD_*
  Summary:
    Command defines.
*/
#define ILI9341_CMD_SLEEP_OUT                       0x11
#define ILI9341_CMD_DISPLAY_ON                      0x29
#define ILI9341_CMD_INTERFACE_PIXEL_FORMAT_SET      0x3A
#define ILI9341_CMD_SET_IMAGE_FUNCTION              0xE9
#define ILI9341_CMD_INTERFACE_MODE_CONTROL          0xB0
#define ILI9341_CMD_MEMORY_ACCESS_CONTROL           0x36
#define ILI9341_CMD_COLUMN_ADDRESS_SET              0x2A
#define ILI9341_CMD_PAGE_ADDRESS_SET                0x2B
#define ILI9341_CMD_MEMORY_WRITE                    0x2C
#define ILI9341_CMD_MEMORY_READ                     0x2E

/** ILI9488_COLOR_PIX_FMT_18BPP
  @Summary
    Color pixel format value for 18BPP
*/
#define ILI9341_COLOR_PIX_FMT_16BPP          0x5
#define ILI9341_COLOR_PIX_FMT_18BPP          0x6

/** ILI9488_MADCTL_*
  Summary:
    Memory access control command parameter bit values.
*/
#define ILI9341_MADCTL_RGB_BGR_ORDER_CTRL           (1 << 3)
#define ILI9341_MADCTL_ROW_COLUMN_EXCHANGE          (1 << 5)
#define ILI9341_MADCTL_COL_ADDR_ORDER               (1 << 6)
#define ILI9341_MADCTL_ROW_ADDR_ORDER               (1 << 7)


    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
